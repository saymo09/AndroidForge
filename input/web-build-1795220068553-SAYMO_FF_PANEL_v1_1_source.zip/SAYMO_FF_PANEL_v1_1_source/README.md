# SAYMO FF PANEL — v1.1

## Etapa 2: painel flutuante
- Botão flutuante "S" arrastável.
- Toque para abrir/fechar o painel rápido.
- Atalhos para abrir o app e recolher o painel.
- Serviço em primeiro plano com notificação persistente.
- Permissão Android `SYSTEM_ALERT_WINDOW`.

## Recursos da v1.0 mantidos
- Ajustes de sensibilidade como valores de referência.
- Preferências salvas localmente.
- Personalização de HUD como referência.
- Contador manual de treino.

## Como compilar
1. Abra a pasta `SAYMO_FF_PANEL` no Android Studio.
2. Use JDK 17 e Android SDK 35.
3. Aguarde a sincronização do Gradle.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).

## Como testar a sobreposição
1. Instale e abra o app.
2. Toque em "CONCEDER PERMISSÃO".
3. Na tela do Android, permita "Exibir sobre outros apps" para SAYMO FF PANEL.
4. Volte ao app e toque em "ATIVAR PAINEL FLUTUANTE".
5. Arraste o círculo "S" e toque nele para abrir o painel.
6. Use "PARAR PAINEL FLUTUANTE" no app para encerrar o serviço.

## Observações
- O Android exige que o usuário conceda manualmente a permissão de sobreposição.
- Em alguns aparelhos, a economia de bateria pode encerrar o serviço.
- `targetSdk` está em 33 para manter o serviço foreground compatível sem declarar tipos especiais
  obrigatórios em Android 14+. Para publicação em loja, revise os requisitos atuais de SDK e políticas.
- O painel é uma sobreposição independente: não lê a tela, não interage com controles do Free Fire,
  não altera arquivos/memória/rede do jogo e não implementa aimbot ou ESP.
