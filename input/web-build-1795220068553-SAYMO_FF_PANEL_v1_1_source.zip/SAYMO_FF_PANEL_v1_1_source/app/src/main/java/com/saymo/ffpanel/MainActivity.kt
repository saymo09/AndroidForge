package com.saymo.ffpanel

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF09090D)
private val Panel = Color(0xFF17171F)
private val Red = Color(0xFFFF3B30)
private val Orange = Color(0xFFFF7A24)
private val Muted = Color(0xFF9A9AA6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("saymo_settings", MODE_PRIVATE)
        setContent {
            var tab by remember { mutableIntStateOf(0) }
            var general by remember { mutableFloatStateOf(prefs.getFloat("general", 85f)) }
            var redDot by remember { mutableFloatStateOf(prefs.getFloat("redDot", 90f)) }
            var scope2x by remember { mutableFloatStateOf(prefs.getFloat("scope2x", 80f)) }
            var scope4x by remember { mutableFloatStateOf(prefs.getFloat("scope4x", 75f)) }
            var awm by remember { mutableFloatStateOf(prefs.getFloat("awm", 45f)) }
            var hud by remember { mutableFloatStateOf(prefs.getFloat("hud", 65f)) }
            var vibration by remember { mutableStateOf(prefs.getBoolean("vibration", false)) }
            var sound by remember { mutableStateOf(prefs.getBoolean("sound", true)) }
            var overlayAllowed by remember { mutableStateOf(Settings.canDrawOverlays(this)) }

            MaterialTheme(colorScheme = darkColorScheme(
                background = Bg, surface = Panel, primary = Red,
                secondary = Orange, onBackground = Color.White, onSurface = Color.White
            )) {
                Scaffold(containerColor = Bg, bottomBar = {
                    NavigationBar(containerColor = Panel, contentColor = Color.White) {
                        NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                            icon = { Icon(Icons.Default.Tune, null) }, label = { Text("Ajustes") })
                        NavigationBarItem(selected = tab == 1, onClick = { tab = 1 },
                            icon = { Icon(Icons.Default.SportsEsports, null) }, label = { Text("Treino") })
                        NavigationBarItem(selected = tab == 2, onClick = { tab = 2 },
                            icon = { Icon(Icons.Default.Info, null) }, label = { Text("Sobre") })
                    }
                }) { padding ->
                    Column(Modifier.fillMaxSize().padding(padding)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 18.dp, vertical = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Header()
                        when (tab) {
                            0 -> {
                                SectionTitle("PAINEL FLUTUANTE", "Ative um botão independente sobre outros aplicativos.")
                                Card(colors = CardDefaults.cardColors(containerColor = Panel),
                                    shape = RoundedCornerShape(16.dp)) {
                                    Column(Modifier.padding(15.dp),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text(if (Settings.canDrawOverlays(this@MainActivity)) "Permissão liberada" else "Permissão necessária",
                                            color = if (Settings.canDrawOverlays(this@MainActivity)) Color(0xFF70D99A) else Orange,
                                            fontWeight = FontWeight.Bold)
                                        Text("O Android exige autorização para mostrar o botão sobre outros apps.",
                                            color = Muted, fontSize = 12.sp)
                                        Button(onClick = {
                                            if (!Settings.canDrawOverlays(this@MainActivity)) {
                                                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                                    Uri.parse("package:$packageName"))
                                                startActivity(intent)
                                            } else {
                                                val serviceIntent = Intent(this@MainActivity, FloatingPanelService::class.java)
                                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                                                    startForegroundService(serviceIntent)
                                                else startService(serviceIntent)
                                            }
                                        }, modifier = Modifier.fillMaxWidth(),
                                            colors = ButtonDefaults.buttonColors(containerColor = Red)) {
                                            Text("PERMISSÃO / ATIVAR PAINEL FLUTUANTE")
                                        }
                                        OutlinedButton(onClick = {
                                            val stop = Intent(this@MainActivity, FloatingPanelService::class.java)
                                            stop.action = FloatingPanelService.ACTION_STOP
                                            startService(stop)
                                        }, modifier = Modifier.fillMaxWidth()) {
                                            Text("PARAR PAINEL FLUTUANTE")
                                        }
                                        Text("Depois de conceder a permissão, volte ao app e toque em Ativar.",
                                            color = Muted, fontSize = 11.sp)
                                    }
                                }
                                SectionTitle("CONFIGURAÇÕES DE SENSIBILIDADE", "Valores de referência salvos neste aparelho.")
                                SliderCard("Geral", general) { general = it; prefs.edit().putFloat("general", it).apply() }
                                SliderCard("Ponto vermelho", redDot) { redDot = it; prefs.edit().putFloat("redDot", it).apply() }
                                SliderCard("Mira 2x", scope2x) { scope2x = it; prefs.edit().putFloat("scope2x", it).apply() }
                                SliderCard("Mira 4x", scope4x) { scope4x = it; prefs.edit().putFloat("scope4x", it).apply() }
                                SliderCard("AWM / Sniper", awm) { awm = it; prefs.edit().putFloat("awm", it).apply() }
                                SectionTitle("PERSONALIZAÇÃO", "Preferências locais do aplicativo.")
                                SliderCard("Escala de referência do HUD", hud) { hud = it; prefs.edit().putFloat("hud", it).apply() }
                                ToggleCard("Vibração nos controles do app", vibration) { vibration = it; prefs.edit().putBoolean("vibration", it).apply() }
                                ToggleCard("Sons da interface", sound) { sound = it; prefs.edit().putBoolean("sound", it).apply() }
                                Text("Os valores são referências editáveis. O painel flutuante não aplica alterações no Free Fire.",
                                    color = Muted, fontSize = 12.sp)
                            }
                            1 -> TrainingScreen()
                            else -> AboutScreen()
                        }
                        Spacer(Modifier.height(10.dp))
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Compose reads the permission state when the screen is recreated/resumed.
    }
}

@Composable private fun Header() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(48.dp).background(Red, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Bolt, null, tint = Color.White, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("SAYMO", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black)
            Text("FF PANEL  •  V1.1", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Surface(color = Color(0xFF202028), shape = RoundedCornerShape(50)) {
            Text("OVERLAY", color = Color(0xFF7EE0A1), fontSize = 10.sp,
                fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp))
        }
    }
}
@Composable private fun SectionTitle(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(title, color = Orange, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
        Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}
@Composable private fun SliderCard(title: String, value: Float, onChange: (Float) -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(15.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Text(value.toInt().toString(), color = Orange, fontWeight = FontWeight.Bold)
            }
            Slider(value = value, onValueChange = onChange, valueRange = 0f..100f,
                colors = SliderDefaults.colors(thumbColor = Red, activeTrackColor = Red))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("0", color = Muted, fontSize = 10.sp); Text("100", color = Muted, fontSize = 10.sp)
            }
        }
    }
}
@Composable private fun ToggleCard(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 15.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = Color.White, modifier = Modifier.weight(1f), fontSize = 14.sp)
            Switch(checked = checked, onCheckedChange = onChange,
                colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Red))
        }
    }
}
@Composable private fun TrainingScreen() {
    var reps by remember { mutableIntStateOf(0) }
    var seconds by remember { mutableIntStateOf(30) }
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SectionTitle("CENTRO DE TREINAMENTO", "Ferramentas independentes para praticar sua mira.")
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(Icons.Default.GpsFixed, null, tint = Red, modifier = Modifier.size(42.dp))
                Text("CONTADOR DE TREINO", color = Color.White, fontWeight = FontWeight.Bold)
                Text("$reps acertos registrados", color = Orange, fontSize = 25.sp, fontWeight = FontWeight.Black)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { reps++ }, colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("Registrar acerto") }
                    OutlinedButton(onClick = { reps = 0 }) { Text("Zerar") }
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("ROTINA DE PRÁTICA", color = Color.White, fontWeight = FontWeight.Bold)
                Text("Escolha a duração de uma sessão.", color = Muted, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(15, 30, 45, 60).forEach { time ->
                        FilterChip(selected = seconds == time, onClick = { seconds = time }, label = { Text("${time}s") })
                    }
                }
                Text("Sessão selecionada: $seconds segundos", color = Orange)
            }
        }
        Text("O módulo registra sua prática manualmente; não lê a tela nem interage com partidas.",
            color = Muted, fontSize = 12.sp)
    }
}
@Composable private fun AboutScreen() {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionTitle("SOBRE O PROJETO", "SAYMO FF PANEL — versão 1.1.")
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("Recursos", color = Orange, fontWeight = FontWeight.Bold)
                listOf("Painel flutuante arrastável", "Ativação por permissão Android",
                    "Ajustes de referência salvos localmente", "Contador manual de treino",
                    "Interface escura em vermelho e laranja").forEach {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF70D99A), modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(8.dp)); Text(it, color = Color.White, fontSize = 13.sp)
                    }
                }
            }
        }
        Text("Aplicativo independente. Não modifica arquivos, memória, rede ou funcionamento do Free Fire.",
            color = Muted, fontSize = 12.sp)
    }
}
