package com.saymo.ffpanel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class FloatingPanelService : Service() {
    private lateinit var windowManager: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var expanded = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(41, buildNotification())
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopOverlay()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun baseParams(width: Int, height: Int): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            width, height, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 220
        }

    private fun rounded(color: Int, radius: Float): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
            setStroke(dp(1), Color.rgb(255, 90, 60))
        }

    private fun showBubble() {
        if (bubble != null) return
        val view = TextView(this).apply {
            text = "S"
            textSize = 21f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(220, 42, 35), dp(28).toFloat())
            elevation = dp(8).toFloat()
            contentDescription = "Abrir painel SAYMO"
        }
        val params = baseParams(dp(54), dp(54))
        bubble = view
        bubbleParams = params
        attachDrag(view, params) { togglePanel() }
        windowManager.addView(view, params)
    }

    private fun attachDrag(view: View, params: WindowManager.LayoutParams, onTap: () -> Unit) {
        var startX = 0
        var startY = 0
        var downX = 0f
        var downY = 0f
        var moved = false
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    downX = event.rawX
                    downY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > dp(5) || kotlin.math.abs(dy) > dp(5)) moved = true
                    params.x = startX + dx
                    params.y = startY + dy
                    try { windowManager.updateViewLayout(view, params) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onTap()
                    true
                }
                else -> true
            }
        }
    }

    private fun togglePanel() {
        if (expanded) {
            removePanel()
            return
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(Color.rgb(20, 20, 27), dp(18).toFloat())
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "SAYMO  •  QUICK PANEL"
            textSize = 13f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val close = TextView(this).apply {
            text = "  ×"
            textSize = 24f
            setTextColor(Color.rgb(255, 110, 75))
            gravity = Gravity.CENTER
            setOnClickListener { removePanel() }
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(36), 1f))
        header.addView(close, LinearLayout.LayoutParams(dp(36), dp(36)))
        content.addView(header)

        addValueRow(content, "Sensibilidade geral", "Ajuste no app")
        addValueRow(content, "Ponto vermelho", "Ajuste no app")
        addValueRow(content, "HUD de referência", "Personalização")
        addActionButton(content, "ABRIR SAYMO FF PANEL") {
            val launch = packageManager.getLaunchIntentForPackage(packageName)
            launch?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (launch != null) startActivity(launch)
        }
        addActionButton(content, "RECOLHER PAINEL") { removePanel() }
        val note = TextView(this).apply {
            text = "Sobreposição independente. Não altera nem controla o jogo."
            textSize = 10f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(8), 0, 0)
        }
        content.addView(note)

        val params = baseParams(dp(250), WindowManager.LayoutParams.WRAP_CONTENT).apply {
            x = (bubbleParams?.x ?: dp(24))
            y = (bubbleParams?.y ?: dp(220)) + dp(62)
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        }
        panel = content
        panelParams = params
        windowManager.addView(content, params)
        expanded = true
    }

    private fun addValueRow(parent: LinearLayout, label: String, value: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        val main = TextView(this).apply {
            text = label
            textSize = 12f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val sub = TextView(this).apply {
            text = value
            textSize = 10f
            setTextColor(Color.rgb(255, 140, 95))
        }
        row.addView(main)
        row.addView(sub)
        parent.addView(row)
    }

    private fun addActionButton(parent: LinearLayout, label: String, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            textSize = 10f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(180, 38, 32), dp(10).toFloat())
            setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(42)
        ).apply { topMargin = dp(6) }
        parent.addView(button, lp)
    }

    private fun removePanel() {
        panel?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        panel = null
        panelParams = null
        expanded = false
    }

    private fun stopOverlay() {
        removePanel()
        bubble?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        bubble = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "SAYMO painel flutuante",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID)
        else @Suppress("DEPRECATION") Notification.Builder(this)
        return builder.setContentTitle("SAYMO FF PANEL ativo")
            .setContentText("Toque no botão flutuante para abrir os controles.")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        removePanel()
        bubble?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        bubble = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.saymo.ffpanel.STOP_OVERLAY"
        private const val CHANNEL_ID = "saymo_overlay"
    }
}
